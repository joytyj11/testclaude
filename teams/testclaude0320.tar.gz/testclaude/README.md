# testclaude 团队

## 团队架构

testclaude 团队由两个专业agent组成，专注于编码任务的完整生命周期管理。

### 1. 编排agent (orchestrator)
- **角色**：协调者
- **职责**：接收高层次需求，任务分解，协调编码agent，监控进度，清理已完成任务，重启失败任务
- **配置**：`/home/administrator/.openclaw-zero/workspace/orchestrator-config.json`
- **模式**：session（持久会话）

### 2. 编码agent (coder)
- **角色**：执行者
- **职责**：具体编码实现，功能开发，bug修复，测试编写，代码重构
- **配置**：`/home/administrator/.openclaw-zero/workspace/coding-agent-config.json`
- **模式**：run（一次性任务）

## 工作流程

```
用户输入 → 编排agent → 任务分解 → 生成任务提示 → 启动多个编码agent（并行）
                     ↓
                监控所有编码agent状态
                     ↓
                自动重启失败任务（最多3次）
                     ↓
                收集结果 → 整合输出
                     ↓
                清理已完成任务
```

## 如何使用

### 启动团队
```bash
# 启动编排agent（团队入口）
sessions_spawn --runtime=subagent --agentId=orchestrator-agent --task="请处理以下任务：..."
```

### 查看团队状态
```bash
# 查看所有活跃的编码agent
check-agents.sh
```

### 清理已完成任务
```bash
# 清理所有已完成的任务
cleanup-agents.sh
```

### 手动重启失败任务
```bash
# 重启指定任务
respawn-agent.sh <task-id>
```

## 团队特点

- ✅ **并行执行**：可以同时启动多个编码agent处理不同子任务
- ✅ **智能监控**：自动检测异常状态（stuck/failed）
- ✅ **自动重试**：失败任务自动重启，保留失败上下文
- ✅ **自动清理**：完成任务后自动清理worktree和tmux会话
- ✅ **统计追踪**：记录任务成功率、平均完成时间

## 配置文件

团队配置文件：`team-config.json`

```json
{
  "name": "testclaude",
  "agents": [
    {"label": "orchestrator", "role": "coordinator"},
    {"label": "coder", "role": "worker"}
  ],
  "workflow": {
    "input": "orchestrator",
    "delegation": "orchestrator → multiple coders",
    "retry": {"maxAttempts": 3}
  }
}
```

## 相关工具路径

所有脚本都位于：
```
/home/administrator/openclaw-zero-token/.openclaw-upstream-state/swarm/scripts/
├── generate-prompt.sh    # 编码agent生成任务提示
├── spawn-agent.sh        # 编排agent启动编码agent
├── check-agents.sh       # 监控所有编码agent
├── cleanup-agents.sh     # 清理已完成任务
└── respawn-agent.sh      # 重启失败任务
```

## 注意事项

- 编排agent需要持久运行，负责整个任务生命周期的管理
- 编码agent为一次性任务，每个子任务会启动一个新的编码agent实例
- 所有编码agent在独立的git worktree中运行，互不干扰
- 失败任务会自动重试最多3次，每次重试会包含失败上下文

---
*团队创建时间：2026-03-20*